import { createInitialAgents } from '../data/agentDefinitions';
import { AgentSignal, CeoDirective, MarketAgent, SignalType, TechnicalIndicators } from '../types/agent';
import { derivWs, LiveTick } from './derivWs';
import { Candle, colorOf, colorPass, verdict } from './sweep';

export type Mode = 'any' | 'color';
export interface Config { expiry: number; modes: Record<Mode, boolean>; stake: number; payout: number; allowOverlap: boolean }
export interface Trade { id: string; sym: string; book: Mode; dir: 'BUY' | 'SELL'; exp: number; entry: number; t0: number; stake: number; payout: number; openedAt: number }
export interface Done extends Trade { exit: number; res: 'WIN' | 'LOSS' | 'TIE'; at: number }
export interface Tally { n: number; w: number; l: number; t: number; p: number }

const KEY = 'sweepFleetLedger2';
const STALE_S = 20; // CEO rejects a signal if the first tick of the new candle arrives this late (server time)
const raf = (f: () => void) => (typeof requestAnimationFrame !== 'undefined' ? requestAnimationFrame(f) : setTimeout(f, 16));

// Real indicators computed from real closed 1-minute candles only.
const ema = (a: number[], n: number) => { const k = 2 / (n + 1); let e = a[0]; return a.map((v, i) => (i ? (e = v * k + e * (1 - k)) : e)); };
function indicators(c: Candle[]): TechnicalIndicators | null {
  const cl = c.map((x) => x.c);
  if (cl.length < 30) return null;
  let ag = 0, al = 0;
  for (let i = 1; i <= 14; i++) { const d = cl[i] - cl[i - 1]; if (d > 0) ag += d; else al -= d; }
  ag /= 14; al /= 14;
  for (let i = 15; i < cl.length; i++) { const d = cl[i] - cl[i - 1]; ag = (ag * 13 + Math.max(d, 0)) / 14; al = (al * 13 + Math.max(-d, 0)) / 14; }
  const rsi = al === 0 ? 100 : 100 - 100 / (1 + ag / al);
  const e12 = ema(cl, 12), e26 = ema(cl, 26), m = e12.map((v, i) => v - e26[i]), sg = ema(m, 9);
  const w = cl.slice(-20), mean = w.reduce((a, b) => a + b, 0) / w.length;
  const sd = Math.sqrt(w.reduce((a, b) => a + (b - mean) ** 2, 0) / w.length), up = mean + 2 * sd, lo = mean - 2 * sd, last = cl[cl.length - 1];
  const rng = c.slice(-14).reduce((s, x) => s + x.h - x.l, 0) / 14;
  return {
    rsi: Number(rsi.toFixed(1)),
    macd: { macd: m[m.length - 1], signal: sg[sg.length - 1], hist: m[m.length - 1] - sg[sg.length - 1] },
    emaFast: ema(cl, 9)[cl.length - 1], emaSlow: ema(cl, 21)[cl.length - 1],
    bollinger: { upper: up, middle: mean, lower: lo, percentB: up === lo ? 0.5 : Number(((last - lo) / (up - lo)).toFixed(2)) },
    volatilityScore: Math.min(100, Math.round((rng / last) * 10000)), // average 1-minute range in basis points
  };
}

interface SymState { closed: Candle[]; cur: Candle | null }
type StateListener = (agents: MarketAgent[], signals: AgentSignal[], directives: CeoDirective[]) => void;

class AgentEngine {
  private agents = new Map<string, MarketAgent>();
  private st = new Map<string, SymState>();
  private signals: AgentSignal[] = [];
  private directives: CeoDirective[] = [];
  private listeners = new Set<StateListener>();
  private offs: (() => void)[] = [];
  private started = false;
  private armed = false;
  private open: Trade[] = [];
  private done: Done[] = [];
  private seq = 0;
  private pending = false;
  private cfg: Config = { expiry: 1, modes: { any: true, color: false }, stake: 10, payout: 85, allowOverlap: false };

  constructor() {
    for (const a of createInitialAgents()) { this.agents.set(a.assignedSymbol, a); this.st.set(a.assignedSymbol, { closed: [], cur: null }); }
    try { const j = JSON.parse(localStorage.getItem(KEY) || 'null'); if (j) { this.done = j.done || []; this.cfg = { ...this.cfg, ...j.cfg }; } } catch { /* fresh start */ }
    this.agents.forEach((a) => this.refresh(a));
  }

  /** Connects the live feed so charts and prices run. No signals or trades happen until startAutomation(). */
  public start(): void {
    if (this.started) return;
    this.started = true;
    this.offs = [
      derivWs.onSeed((sym, closed, forming, pip) => this.onSeed(sym, closed, forming, pip)),
      derivWs.onTick((t) => this.onTick(t)),
      derivWs.onSymbolError((sym, msg) => { const a = this.agents.get(sym); if (a) { a.status = 'STANDBY'; this.note(`Feed error ${sym}: ${msg}`); this.push(); } }),
    ];
    derivWs.connect();
    derivWs.subscribeSymbols(Array.from(this.agents.keys()));
  }
  public stop(): void { this.started = false; this.offs.forEach((f) => f()); this.offs = []; }

  public startAutomation(): void { this.armed = true; this.note(`Automation ON: every agent is watching for sweeps. Expiry ${this.cfg.expiry} min, ${[this.cfg.modes.any && 'sweep only', this.cfg.modes.color && 'color filter'].filter(Boolean).join(' + ') || 'NO RULE SELECTED'}`); this.push(); }
  public stopAutomation(): void { this.armed = false; this.note('Automation OFF: no new trades. Open trades still settle'); this.push(); }
  public isArmed(): boolean { return this.armed; }

  // ---- agents: one per market, each reacting independently to its own live ticks ----
  private onSeed(sym: string, closed: Candle[], forming: Candle, pip: number): void {
    const a = this.agents.get(sym), s = this.st.get(sym);
    if (!a || !s) return;
    s.closed = closed.slice(-60); s.cur = forming;
    const i = a.assignedInstrument, all = [...closed, forming];
    if (pip) i.pipSize = pip;
    i.openPrice = closed[0]?.o ?? forming.o; i.currentPrice = i.previousPrice = forming.c;
    i.high24h = Math.max(...all.map((c) => c.h)); i.low24h = Math.min(...all.map((c) => c.l));
    i.priceHistory = all.map((c) => c.c).slice(-60); i.lastUpdated = Date.now();
    a.indicators = indicators(s.closed) || a.indicators;
    a.status = 'ACTIVE'; this.push();
  }

  private onTick(t: LiveTick): void {
    const a = this.agents.get(t.symbol), s = this.st.get(t.symbol);
    if (!a || !s || !s.cur) return;
    const i = a.assignedInstrument;
    i.previousPrice = i.currentPrice; i.currentPrice = t.price;
    i.priceHistory = [...i.priceHistory.slice(-59), t.price];
    i.high24h = Math.max(i.high24h, t.price); i.low24h = Math.min(i.low24h, t.price);
    i.change24h = t.price - i.openPrice; i.changePct = i.openPrice ? Number(((i.change24h / i.openPrice) * 100).toFixed(3)) : 0;
    i.lastUpdated = Date.now(); a.metrics.latencyMs = derivWs.latencyMs; a.metrics.uptimePct = 100;
    if (a.status === 'STANDBY' || (a.status === 'SIGNAL_FIRED' && Date.now() - (a.lastSignal?.timestamp || 0) > 8000)) a.status = 'ACTIVE';
    if (t.candle.t === s.cur.t) s.cur = t.candle;
    else if (t.candle.t > s.cur.t) {
      const K = s.cur;
      s.closed = [...s.closed, K].slice(-60); s.cur = t.candle;
      this.onClose(a, s, K, t.candle, t.epoch);
    }
    this.push();
  }

  /** K just closed (its close is final once the first tick of the next minute N arrives). Acts in the same tick, no delay. */
  private onClose(a: MarketAgent, s: SymState, K: Candle, N: Candle, epoch: number): void {
    this.settle(a.assignedSymbol, N);
    a.indicators = indicators(s.closed) || a.indicators;
    a.metrics.totalEvaluations++;
    const P = s.closed[s.closed.length - 2];
    if (!this.armed || a.isMuted || !P || K.t - P.t !== 60 || N.t - K.t !== 60) return;
    const v = verdict(P, K);
    if (!v) return;
    const sig: AgentSignal = {
      id: `sig-${Date.now()}-${a.agentNumber}`, agentId: a.id, agentName: a.name, symbol: a.assignedSymbol,
      assetName: a.assignedInstrument.displayName, category: a.category, signalType: v as SignalType,
      confidence: 100, // rule matched (not a probability)
      priceAtSignal: N.c, targetPrice: N.c, stopLoss: N.c, riskRewardRatio: 0, timestamp: Date.now(),
      rationale: `${v === 'BUY' ? 'Low' : 'High'} of the previous ${colorOf(P) === 'G' ? 'green' : colorOf(P) === 'R' ? 'red' : 'doji'} candle swept; the candle closed back ${v === 'BUY' ? 'at or above the bottom' : 'at or below the top'} of its body.`,
      indicators: { rsi: a.indicators.rsi, macdHist: a.indicators.macd.hist, trend: v === 'BUY' ? 'BULLISH' : 'BEARISH', volatility: 'MEDIUM' }, acknowledgedByCeo: false,
    };
    a.metrics.signalsGenerated++; a.lastSignal = sig; a.status = 'SIGNAL_FIRED';
    a.signalHistory = [sig, ...a.signalHistory.slice(0, 19)];
    this.signals = [sig, ...this.signals.slice(0, 79)];
    this.ceoReceive(a, sig, P, K, N, epoch);
  }

  // ---- CEO: gets every signal instantly, places the paper trade at the chosen expiry on the real price ----
  private ceoReceive(a: MarketAgent, sig: AgentSignal, P: Candle, K: Candle, N: Candle, epoch: number): void {
    const name = a.assignedInstrument.displayName, dir = sig.signalType as 'BUY' | 'SELL';
    if (epoch - N.t > STALE_S) return this.note(`CEO rejected stale ${dir} ${name} (${epoch - N.t}s late)`);
    const placed: string[] = [];
    for (const b of ['any', 'color'] as Mode[]) {
      if (!this.cfg.modes[b]) continue;
      if (b === 'color' && !colorPass(dir, P, K)) continue; // green sweeps red low = BUY, red sweeps green high = SELL
      if (!this.cfg.allowOverlap && this.open.some((x) => x.sym === a.assignedSymbol && x.book === b)) continue;
      this.open.push({ id: `t${++this.seq}`, sym: a.assignedSymbol, book: b, dir, exp: this.cfg.expiry, entry: N.c, t0: N.t, stake: this.cfg.stake, payout: this.cfg.payout / 100, openedAt: Date.now() });
      placed.push(b === 'any' ? 'sweep only' : 'color filter');
    }
    sig.acknowledgedByCeo = placed.length > 0;
    this.note(placed.length ? `CEO placed paper ${dir} ${name} @ ${N.c} for ${this.cfg.expiry} min (${placed.join(' + ')})` : `CEO skipped ${dir} ${name}: no selected rule took it`);
  }

  private settle(sym: string, N: Candle): void {
    let changed = false;
    this.open = this.open.filter((x) => {
      if (x.sym !== sym) return true;
      const due = x.t0 + x.exp * 60;
      if (N.t < due) return true;
      changed = true;
      if (N.t > due) { this.note(`Trade ${x.dir} ${sym} voided: feed missed the exit minute`); return false; }
      const d = (N.c - x.entry) * (x.dir === 'BUY' ? 1 : -1);
      const res = d > 0 ? 'WIN' : d < 0 ? 'LOSS' : 'TIE'; // a tie loses, like a Rise/Fall contract
      this.done.push({ ...x, exit: N.c, res, at: Date.now() });
      this.note(`${res}: ${x.dir} ${this.agents.get(sym)?.assignedInstrument.displayName ?? sym} entry ${x.entry} exit ${N.c}`);
      return false;
    });
    if (changed) { this.done = this.done.slice(-20000); const a = this.agents.get(sym); if (a) this.refresh(a); this.save(); }
  }

  private refresh(a: MarketAgent): void {
    const d = this.done.filter((x) => x.sym === a.assignedSymbol), w = d.filter((x) => x.res === 'WIN').length;
    a.metrics.successfulSignals = w;
    a.metrics.winRate = d.length ? Number(((100 * w) / d.length).toFixed(1)) : 0;
    a.metrics.simulatedPnl = Number(d.reduce((s, x) => s + (x.res === 'WIN' ? x.stake * x.payout : -x.stake), 0).toFixed(2));
  }

  // ---- public API used by the UI ----
  public getConfig(): Config { return { ...this.cfg }; }
  public setConfig(p: Partial<Config>): void { this.cfg = { ...this.cfg, ...p }; this.save(); this.push(); }
  public getOpen(): Trade[] { return this.open; }
  public getRecent(n = 12): Done[] { return this.done.slice(-n).reverse(); }
  public getLiveCount(): number { return Array.from(this.agents.values()).filter((a) => a.status !== 'STANDBY').length; }
  public getSummary(): { all: Tally; bySym: Record<string, Tally>; byBook: Record<Mode, Tally> } {
    const z = (): Tally => ({ n: 0, w: 0, l: 0, t: 0, p: 0 }), all = z(), bySym: Record<string, Tally> = {}, byBook: Record<Mode, Tally> = { any: z(), color: z() };
    for (const x of this.done) {
      for (const c of [all, byBook[x.book], (bySym[x.sym] = bySym[x.sym] || z())]) { c.n++; if (x.res === 'WIN') { c.w++; c.p += x.stake * x.payout; } else { if (x.res === 'LOSS') c.l++; else c.t++; c.p -= x.stake; } }
    }
    return { all, bySym, byBook };
  }
  public exportCsv(): string {
    return 'time,symbol,mode,side,expiry_min,entry,exit,result\n' + this.done.map((x) => [new Date(x.at).toISOString(), x.sym, x.book, x.dir, x.exp, x.entry, x.exit, x.res].join(',')).join('\n');
  }
  public resetLedger(): void { this.done = []; this.open = []; this.agents.forEach((a) => this.refresh(a)); this.save(); this.push(); }
  public getAgentsList(): MarketAgent[] { return Array.from(this.agents.values()).sort((a, b) => a.agentNumber - b.agentNumber); }
  public getSignals(): AgentSignal[] { return this.signals; }
  public getDirectives(): CeoDirective[] { return this.directives; }
  public toggleMuteAgent(symbol: string): void { const a = this.agents.get(symbol); if (a) { a.isMuted = !a.isMuted; this.push(); } }
  public onStateChange(l: StateListener): () => void { this.listeners.add(l); l(this.getAgentsList(), this.signals, this.directives); return () => this.listeners.delete(l); }

  private note(msg: string): void {
    this.directives = [{ id: `dir-${Date.now()}-${++this.seq}`, title: msg, directiveType: 'REBALANCE', priority: 'MEDIUM', description: msg, affectedCount: 1, affectedCategory: 'ALL', timestamp: Date.now(), status: 'COMPLETED' }, ...this.directives.slice(0, 39)];
  }
  private save(): void { try { localStorage.setItem(KEY, JSON.stringify({ done: this.done, cfg: this.cfg })); } catch { /* storage blocked */ } }
  private push(): void {
    if (this.pending) return;
    this.pending = true;
    raf(() => { this.pending = false; const l = this.getAgentsList(); this.listeners.forEach((f) => f(l, this.signals, this.directives)); });
  }
}

export const agentEngine = new AgentEngine();
