export interface Candle { t: number; o: number; h: number; l: number; c: number }
export type Verdict = 'BUY' | 'SELL' | null;
export const colorOf = (k: Candle) => (k.c > k.o ? 'G' : k.c < k.o ? 'R' : 'D');

/** The confirmed strategy: price sweeps the liquidity (takes the previous candle's low or high) and the
 *  sweep candle closes back at the swept candle's body. Candle color does not matter.
 *  BUY : K.low  < P.low  and K.close >= bottom of P's body (back inside it, or through it upward).
 *  SELL: K.high > P.high and K.close <= top of P's body (back inside it, or through it downward).
 *  A close that stays beyond the sweep side of the body is a fake sweep: no trade.
 *  Both sides swept with the close inside the body is ambiguous: no trade. */
export function verdict(P: Candle, K: Candle): Verdict {
  const top = Math.max(P.o, P.c), bot = Math.min(P.o, P.c);
  const b = K.l < P.l && K.c >= bot, s = K.h > P.h && K.c <= top;
  return b && s ? null : b ? 'BUY' : s ? 'SELL' : null;
}

/** Optional color filter: green sweeps the low of a red candle = BUY, red sweeps the high of a green candle = SELL. */
export const colorPass = (dir: 'BUY' | 'SELL', P: Candle, K: Candle) =>
  dir === 'BUY' ? colorOf(K) === 'G' && colorOf(P) === 'R' : colorOf(K) === 'R' && colorOf(P) === 'G';
