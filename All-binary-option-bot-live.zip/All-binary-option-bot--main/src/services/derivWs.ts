import { Candle } from './sweep';

export type ConnectionStatus = 'CONNECTED' | 'STREAMING' | 'RECONNECTING' | 'CONNECTING' | 'OFFLINE';
export interface LiveTick { symbol: string; price: number; epoch: number; candle: Candle }

type SeedFn = (symbol: string, closed: Candle[], forming: Candle, pipSize: number) => void;
type TickFn = (t: LiveTick) => void;
type StatusFn = (s: ConnectionStatus) => void;
type ErrFn = (symbol: string, msg: string) => void;

// Real Deriv data only. No simulated or random ticks anywhere in this file.
// Override the endpoint with VITE_DERIV_WS_URL (e.g. if Deriv moves to its new API address).
const BASE: string = (import.meta as any).env?.VITE_DERIV_WS_URL || 'wss://ws.derivws.com/websockets/v3';
const APP_IDS = ['1089', '10843', '36544', '16929'];
const SHARD_SIZE = 10; // symbols per WebSocket connection
const PACE_MS = 150;   // spacing between subscription requests (rate limit safety)

interface Shard { id: number; syms: string[]; ws: WebSocket | null; status: ConnectionStatus; tries: number; app: number; hb: number | null; gen: number }

class DerivFeed {
  public status: ConnectionStatus = 'CONNECTING';
  public latencyMs = 0;
  public ticksPerSecond = 0;
  public totalTicksReceived = 0;
  public liveDerivTicksCount = 0;
  private shards: Shard[] = [];
  private reqIds = new Map<number, string>();
  private nextReq = 1;
  private queue: { shard: Shard; gen: number; sym: string }[] = [];
  private pacer: number | null = null;
  private tickCount = 0;
  private lastPing = 0;
  private started = false;
  private seedL = new Set<SeedFn>(); private tickL = new Set<TickFn>();
  private statL = new Set<StatusFn>(); private errL = new Set<ErrFn>();
  private rateTimer: number | null = null;

  public connect(): void {
    if (this.started) return;
    this.started = true;
    this.rateTimer = window.setInterval(() => { this.ticksPerSecond = this.tickCount; this.tickCount = 0; }, 1000);
    this.shards.forEach((s) => this.open(s));
  }

  public subscribeSymbols(symbols: string[]): void {
    for (const sym of symbols) {
      if (this.shards.some((s) => s.syms.includes(sym))) continue;
      let sh = this.shards.find((s) => s.syms.length < SHARD_SIZE);
      if (!sh) {
        sh = { id: this.shards.length, syms: [], ws: null, status: 'CONNECTING', tries: 0, app: 0, hb: null, gen: 0 };
        this.shards.push(sh);
        if (this.started) this.open(sh);
      }
      sh.syms.push(sym);
      if (sh.ws && sh.ws.readyState === WebSocket.OPEN) this.enqueue(sh, sym);
    }
  }

  private open(sh: Shard): void {
    sh.gen++;
    const gen = sh.gen;
    this.setShard(sh, 'CONNECTING');
    let ws: WebSocket;
    try { ws = sh.ws = new WebSocket(`${BASE}?app_id=${APP_IDS[sh.app]}`); } catch { return this.retry(sh); }
    ws.onopen = () => {
      sh.tries = 0;
      this.setShard(sh, 'CONNECTED');
      sh.hb = window.setInterval(() => { if (ws.readyState === 1) { this.lastPing = Date.now(); ws.send('{"ping":1}'); } }, 10000);
      sh.syms.forEach((s) => this.enqueue(sh, s));
    };
    ws.onmessage = (e) => { try { this.onMsg(sh, JSON.parse(e.data)); } catch { /* ignore bad frame */ } };
    ws.onerror = () => { /* onclose follows */ };
    ws.onclose = () => {
      if (sh.hb !== null) { clearInterval(sh.hb); sh.hb = null; }
      if (sh.gen !== gen) return;
      this.setShard(sh, 'RECONNECTING');
      this.retry(sh);
    };
  }

  private retry(sh: Shard): void {
    sh.tries++;
    sh.app = (sh.app + 1) % APP_IDS.length;
    window.setTimeout(() => this.started && this.open(sh), Math.min(30000, 1500 * sh.tries));
  }

  private enqueue(sh: Shard, sym: string): void {
    this.queue.push({ shard: sh, gen: sh.gen, sym });
    if (this.pacer !== null) return;
    this.pacer = window.setInterval(() => {
      const job = this.queue.shift();
      if (!job) { clearInterval(this.pacer!); this.pacer = null; return; }
      const ws = job.shard.ws;
      if (job.gen !== job.shard.gen || !ws || ws.readyState !== 1) return;
      const id = this.nextReq++;
      this.reqIds.set(id, job.sym);
      // One subscription per market: 60 candle history, then an 'ohlc' message on every live tick.
      ws.send(JSON.stringify({ ticks_history: job.sym, adjust_start_time: 1, count: 60, end: 'latest', granularity: 60, style: 'candles', subscribe: 1, req_id: id }));
    }, PACE_MS);
  }

  private onMsg(sh: Shard, m: any): void {
    if (m.msg_type === 'ping') { if (this.lastPing) this.latencyMs = Date.now() - this.lastPing; return; }
    if (m.error) {
      const sym = this.reqIds.get(m.req_id) || m.echo_req?.ticks_history || '';
      this.errL.forEach((f) => f(sym, m.error.message || m.error.code));
      return;
    }
    if (m.msg_type === 'candles' && Array.isArray(m.candles)) {
      const sym = this.reqIds.get(m.req_id) || m.echo_req?.ticks_history;
      if (!sym) return;
      const arr: Candle[] = m.candles.map((c: any) => ({ t: +c.epoch, o: +c.open, h: +c.high, l: +c.low, c: +c.close }));
      const forming = arr.pop();
      if (forming) this.seedL.forEach((f) => f(sym, arr, forming, Number(m.pip_size) || 0));
    } else if (m.msg_type === 'ohlc' && m.ohlc) {
      const o = m.ohlc;
      const candle: Candle = { t: +o.open_time, o: +o.open, h: +o.high, l: +o.low, c: +o.close };
      this.liveDerivTicksCount++; this.totalTicksReceived++; this.tickCount++;
      this.setShard(sh, 'STREAMING');
      const tick: LiveTick = { symbol: o.symbol, price: candle.c, epoch: +o.epoch, candle };
      this.tickL.forEach((f) => f(tick));
    }
  }

  private setShard(sh: Shard, s: ConnectionStatus): void {
    sh.status = s;
    const all = this.shards.map((x) => x.status);
    const agg: ConnectionStatus = all.includes('STREAMING') ? 'STREAMING' : all.includes('CONNECTED') ? 'CONNECTED'
      : all.includes('RECONNECTING') ? 'RECONNECTING' : all.includes('CONNECTING') ? 'CONNECTING' : 'OFFLINE';
    if (agg !== this.status) { this.status = agg; this.statL.forEach((f) => f(agg)); }
  }

  public onSeed(f: SeedFn) { this.seedL.add(f); return () => this.seedL.delete(f); }
  public onTick(f: TickFn) { this.tickL.add(f); return () => this.tickL.delete(f); }
  public onSymbolError(f: ErrFn) { this.errL.add(f); return () => this.errL.delete(f); }
  public onStatusChange(f: StatusFn) { this.statL.add(f); f(this.status); return () => this.statL.delete(f); }

  public destroy(): void {
    this.started = false;
    if (this.rateTimer !== null) clearInterval(this.rateTimer);
    if (this.pacer !== null) { clearInterval(this.pacer); this.pacer = null; }
    this.shards.forEach((s) => { s.gen++; if (s.hb !== null) clearInterval(s.hb); s.ws?.close(); s.ws = null; });
    this.queue = [];
  }
}

export const derivWs = new DerivFeed();
