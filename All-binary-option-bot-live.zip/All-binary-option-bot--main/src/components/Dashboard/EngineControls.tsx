import React, { useEffect, useState } from 'react';
import { agentEngine, Mode } from '../../services/agentEngine';

const inp = 'bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-slate-100';
const nameOf = (sym: string) => agentEngine.getAgentsList().find((a) => a.assignedSymbol === sym)?.assignedInstrument.displayName ?? sym;

export function EngineControls() {
  const [, tick] = useState(0);
  useEffect(() => {
    const off = agentEngine.onStateChange(() => tick((n) => n + 1));
    const t = setInterval(() => tick((n) => n + 1), 1000);
    return () => { off(); clearInterval(t); };
  }, []);
  const cfg = agentEngine.getConfig(), armed = agentEngine.isArmed();
  const { all, byBook } = agentEngine.getSummary(), open = agentEngine.getOpen(), recent = agentEngine.getRecent(10);
  const be = 100 / (1 + cfg.payout / 100), wr = all.n ? (100 * all.w) / all.n : 0;
  const csv = () => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([agentEngine.exportCsv()], { type: 'text/csv' }));
    a.download = 'paper_trades.csv'; a.click();
  };
  return (
    <section className="px-3 md:px-6 py-3 border-b border-slate-800 bg-slate-900/60 text-xs text-slate-300 space-y-3">
      <div className="flex flex-wrap items-center gap-3">
        <button onClick={() => (armed ? agentEngine.stopAutomation() : agentEngine.startAutomation())}
          className={`px-4 py-2 rounded-lg font-bold text-sm ${armed ? 'bg-rose-500 text-slate-950' : 'bg-emerald-500 text-slate-950'}`}>
          {armed ? 'Stop automation' : 'Start automation'}
        </button>
        <span className={armed ? 'text-emerald-400 font-semibold' : 'text-slate-400'}>{armed ? 'ARMED: all agents are watching for sweeps' : 'IDLE: feed is live, no trades'}</span>
        <span>{agentEngine.getLiveCount()} markets streaming</span>
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <span>Expiry</span>
        {[1, 2, 3, 4, 5].map((e) => (
          <button key={e} onClick={() => agentEngine.setConfig({ expiry: e })} className={`${inp} ${cfg.expiry === e ? 'border-cyan-400 text-cyan-300' : ''}`}>{e} min</button>
        ))}
        <span className="ml-2">Rules (select one or both)</span>
        {(['any', 'color'] as Mode[]).map((m) => (
          <button key={m} onClick={() => agentEngine.setConfig({ modes: { ...cfg.modes, [m]: !cfg.modes[m] } })} className={`${inp} ${cfg.modes[m] ? 'border-cyan-400 text-cyan-300' : ''}`}>
            {cfg.modes[m] ? '✓ ' : ''}{m === 'any' ? 'Sweep only (any color)' : 'Color filter (green over red = BUY, red over green = SELL)'}
          </button>
        ))}
        {!cfg.modes.any && !cfg.modes.color && <span className="text-amber-400">Select at least one rule</span>}
        <label>Stake <input className={`${inp} w-16`} type="number" min={1} value={cfg.stake} onChange={(e) => agentEngine.setConfig({ stake: +e.target.value || 1 })} /></label>
        <label>Payout % <input className={`${inp} w-16`} type="number" min={1} max={100} value={cfg.payout} onChange={(e) => agentEngine.setConfig({ payout: +e.target.value || 85 })} /></label>
        <label className="flex items-center gap-1"><input type="checkbox" checked={cfg.allowOverlap} onChange={(e) => agentEngine.setConfig({ allowOverlap: e.target.checked })} />allow overlapping trades</label>
        <button className={inp} onClick={csv}>Export CSV</button>
        <button className={inp} onClick={() => confirm('Reset all paper results?') && agentEngine.resetLedger()}>Reset</button>
      </div>
      <div className="flex flex-wrap gap-x-6 gap-y-1 tabular-nums">
        <span>Trades <b>{all.n}</b></span>
        <span className="text-emerald-400">Wins <b>{all.w}</b></span>
        <span className="text-rose-400">Losses <b>{all.l}</b></span>
        <span>Ties <b>{all.t}</b></span>
        <span>Win rate <b className={all.n ? (wr >= be ? 'text-emerald-400' : 'text-rose-400') : ''}>{all.n ? wr.toFixed(1) + '%' : '-'}</b> (breakeven {be.toFixed(1)}%)</span>
        <span>P/L <b className={all.p >= 0 ? 'text-emerald-400' : 'text-rose-400'}>{all.p.toFixed(2)}</b></span>
      </div>
      {byBook.any.n + byBook.color.n > 0 && (
        <div className="flex flex-wrap gap-x-6 gap-y-1 tabular-nums text-slate-400">
          {(['any', 'color'] as Mode[]).map((m) => { const t = byBook[m]; return (
            <span key={m}>{m === 'any' ? 'Sweep only' : 'Color filter'}: {t.n} trades, {t.w}W / {t.l}L, {t.n ? ((100 * t.w) / t.n).toFixed(1) + '%' : '-'}, P/L {t.p.toFixed(2)}</span>); })}
        </div>
      )}
      <div className="grid md:grid-cols-2 gap-3">
        <div>
          <div className="text-slate-400 mb-1">Open paper trades ({open.length})</div>
          {open.length === 0 && <div className="text-slate-500">None</div>}
          {open.map((t) => {
            const left = Math.max(0, Math.round(t.exp * 60 - (Date.now() - t.openedAt) / 1000));
            return <div key={t.id} className="flex justify-between"><span>{nameOf(t.sym)} <i className="text-slate-500">{t.book === 'any' ? 'sweep' : 'color'}</i> <b className={t.dir === 'BUY' ? 'text-emerald-400' : 'text-rose-400'}>{t.dir}</b> @ {t.entry}</span><span>{t.exp}m, {left}s left</span></div>;
          })}
        </div>
        <div>
          <div className="text-slate-400 mb-1">Results</div>
          {recent.length === 0 && <div className="text-slate-500">No settled trades yet</div>}
          {recent.map((t) => (
            <div key={t.id + t.at} className="flex justify-between"><span>{nameOf(t.sym)} <i className="text-slate-500">{t.book === 'any' ? 'sweep' : 'color'}</i> {t.dir} {t.entry} to {t.exit}</span>
              <b className={t.res === 'WIN' ? 'text-emerald-400' : t.res === 'LOSS' ? 'text-rose-400' : 'text-amber-400'}>{t.res}</b></div>
          ))}
        </div>
      </div>
    </section>
  );
}
