import React, { useEffect, useState } from 'react';
import { agentEngine } from '../../services/agentEngine';

/** Real results only: every number comes from settled paper trades on live Deriv prices. */
export const ReportsTab = (_props: any) => {
  const [, tick] = useState(0);
  useEffect(() => agentEngine.onStateChange(() => tick((n) => n + 1)), []);
  const { all, bySym } = agentEngine.getSummary();
  const agents = agentEngine.getAgentsList();
  const rows = Object.entries(bySym).sort((a, b) => b[1].n - a[1].n);
  const cat = (c: string) => rows.filter(([s]) => agents.find((a) => a.assignedSymbol === s)?.category === c).reduce((t, [, v]) => ({ n: t.n + v.n, w: t.w + v.w, p: t.p + v.p }), { n: 0, w: 0, p: 0 });
  const f = cat('forex'), sy = cat('synthetic'), pct = (w: number, n: number) => (n ? ((100 * w) / n).toFixed(1) + '%' : '-');
  return (
    <div className="space-y-4 text-sm text-slate-200">
      <h2 className="text-lg font-semibold">Paper trading results</h2>
      <div className="grid grid-cols-3 gap-3 tabular-nums">
        {[['All markets', all.n, all.w, all.p], ['Forex', f.n, f.w, f.p], ['Synthetic (random by design)', sy.n, sy.w, sy.p]].map(([l, n, w, p]) => (
          <div key={String(l)} className="rounded-xl border border-slate-800 bg-slate-900 p-3">
            <div className="text-xs text-slate-400">{l}</div>
            <div className="text-xl font-bold">{pct(w as number, n as number)}</div>
            <div className="text-xs text-slate-400">{n} trades, P/L {(p as number).toFixed(2)}</div>
          </div>
        ))}
      </div>
      <table className="w-full tabular-nums text-xs">
        <thead><tr className="text-slate-400 text-right"><th className="text-left">Market</th><th>Trades</th><th>W / L / T</th><th>Win %</th><th>P/L</th></tr></thead>
        <tbody>
          {rows.length === 0 && <tr><td colSpan={5} className="text-slate-500 py-3">No settled trades yet. Start automation and wait for sweeps.</td></tr>}
          {rows.map(([s, v]) => (
            <tr key={s} className="text-right border-t border-slate-800">
              <td className="text-left py-1">{agents.find((a) => a.assignedSymbol === s)?.assignedInstrument.displayName ?? s}</td>
              <td>{v.n}</td><td>{v.w} / {v.l} / {v.t}</td><td>{pct(v.w, v.n)}</td>
              <td className={v.p >= 0 ? 'text-emerald-400' : 'text-rose-400'}>{v.p.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
